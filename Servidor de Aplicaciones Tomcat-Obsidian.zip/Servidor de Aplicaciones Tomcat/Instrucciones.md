- Las capturas deben mostrar el nombre de la máquina virtual.
- El nombre de la máquina debe incluir la inicial y apellido del alumno.
- Las capturas deben ser legibles.
- La entrega se realizará en Moodle en PDF.

---

## Objetivo de la tarea
Poner en práctica la instalación y administración del contenedor de servlets y JSP Apache Tomcat.

---

## Entorno de trabajo
- **Sistema anfitrión:** Equipo personal  
- **Sistemas huésped:**  
  - Xubuntu 25.04 (VirtualBox)  
  - Windows 7 con XAMPP  
- **Software:** Apache Tomcat  

---

## Entrega
1. Crear un PDF llamado `Tarea3_1_TuNombre_TuApellido.pdf`
2. Incluir capturas con explicación
3. Responder a las cuestiones
4. Autoevaluación

---

## Rúbrica de autoevaluación
| Parte | Estado           | Comentarios |
| ----- | ---------------- | ----------- |
| 1.1   | OK               |             |
| 1.2   | OK               |             |
| 1.3   | OK               |             |
| 1.4   | OK               |             |
| 1.5   | OK               |             |
| 1.6   | OK               |             |
| 1.7   | OK               |             |
|       | **Nota final:**  |             |

